/********************************************************************************************
* SIDH: an efficient supersingular isogeny cryptography library
*
* Abstract: supersingular isogeny parameters and generation of functions for P503
*********************************************************************************************/

#include "P503_api.h"
#include "P503_internal.h"

// Encoding of field elements, elements over Z_order, elements over GF(p^2) and elliptic curve points:
// --------------------------------------------------------------------------------------------------
// Elements over GF(p) and Z_order are encoded with the least significant octet (and digit) located at the leftmost position (i.e., little endian format).
// Elements (a+b*i) over GF(p^2), where a and b are defined over GF(p), are encoded as {a, b}, with a in the least significant position.
// Elliptic curve points P = (x,y) are encoded as {x, y}, with x in the least significant position.
// Internally, the number of digits used to represent all these elements is obtained by approximating the number of bits to the immediately greater multiple of 32.
// For example, a 503-bit field element is represented with Ceil(503 / 64) = 8 64-bit digits or Ceil(503 / 32) = 16 32-bit digits.

//Base curve Huff curve: C0x(y^2-1)=(x^2-1) which corresponds to Montgomery curve  y^2=x^3+6x^2+x
const uint64_t C0[NWORDS64_FIELD] = {0xA469BEBE305C75B5, 0xC9B043EAB793F5DA, 0x69DB4F3D697780D0, 0x61AD4417DF9A4D0C,
                                     0x64C0E6000ED7E40F, 0x8DEF986293A1BA44, 0xCC04C548FF08B596, 0x00156C3DCA9FDEA6};

const uint64_t p503[NWORDS64_FIELD] = {0xFFFFFFFFFFFFFFFF, 0xFFFFFFFFFFFFFFFF, 0xFFFFFFFFFFFFFFFF, 0xABFFFFFFFFFFFFFF,
                                       0x13085BDA2211E7A0, 0x1B9BF6C87B7E7DAF, 0x6045C6BDDA77A4D0, 0x004066F541811E1E};
const uint64_t p503p1[NWORDS64_FIELD] = {0x0000000000000000, 0x0000000000000000, 0x0000000000000000, 0xAC00000000000000,
                                         0x13085BDA2211E7A0, 0x1B9BF6C87B7E7DAF, 0x6045C6BDDA77A4D0, 0x004066F541811E1E};
const uint64_t p503x2[NWORDS64_FIELD] = {0xFFFFFFFFFFFFFFFE, 0xFFFFFFFFFFFFFFFF, 0xFFFFFFFFFFFFFFFF, 0x57FFFFFFFFFFFFFF,
                                         0x2610B7B44423CF41, 0x3737ED90F6FCFB5E, 0xC08B8D7BB4EF49A0, 0x0080CDEA83023C3C};
// Order of Alice's subgroup
const uint64_t Alice_order[NWORDS64_ORDER] = {0x0000000000000000, 0x0000000000000000, 0x0000000000000000, 0x0400000000000000};
// Order of Bob's subgroup
const uint64_t Bob_order[NWORDS64_ORDER] = {0xC216F6888479E82B, 0xE6FDB21EDF9F6BC4, 0x1171AF769DE93406, 0x1019BD5060478798};

const uint64_t PA_gen[4 * NWORDS64_FIELD] = {0x83AC7529CF0670B7, 0xE72C121A52249BE6, 0x256D7BE5231945E7, 0x3233A3E4EAE55CA7,
                                             0x26D798B42F457022, 0xE27975C23B05C771, 0x5723A9C6064D4869, 0x0000FAF0D6D846E8, //xPA0
                                             0x3EE02578FC8E6472, 0x1D587D332A2E0B26, 0x008463579A3E5E8D, 0x69A98C6D919E4C50,
                                             0xC57F3A8C264DE87F, 0x82E1364D6B2EF2E0, 0x01C56E68E4987FA2, 0x0002EF222C182373, //xPA1
                                             0x977E380E6FDF7941, 0x1324184450204C7B, 0xB88F46ECE7280C82, 0x36BD8EE5B0AB7FA7,
                                             0x0601DCFD916D7B37, 0x449EC4447C89FFF0, 0xD339C77E5C878E7E, 0x0012374D780A4BED, //yPA0
                                             0xE9535D4AD56FDD83, 0x6C31715884F446E7, 0x0F5D522A882E49A4, 0x4CD6686BBA40D82A,
                                             0xA4AB20FAB503D409, 0x22D0EEF14545F125, 0xC8AD926CF198431A, 0x001D6ECC59421029}; //yPA1

const uint64_t QA_gen[4 * NWORDS64_FIELD] = {0x1441732CD6045B6A, 0x42B0F9AAD8E9E3A4, 0x155EBC10F37458AC, 0x2D151D59ED8F86E1,
                                             0xE483240E14D36518, 0x45F6FF71058A5BF0, 0x5F7CE937D2BF6C11, 0x001881C2FB352D27, //xQA0
                                             0x2792F61042A09FE3, 0xA43CF8E7026D181C, 0x4A4F8617A39B20F7, 0xAC9CA01C0FE7943C,
                                             0xE22E035D537C74DA, 0x2C33C5493E3B2C1B, 0x70CE0E9FEAF2E977, 0x001B17B58DF7016C, //xQA1
                                             0xA199341FAD573A6B, 0xC3F296870720D4B4, 0x704D5FA728360CAC, 0x4716C08D06CAAC2C,
                                             0x6AB625C98654B921, 0x5D9A1AE0E43A419C, 0xE1AD20019FDC2D6C, 0x0006CAD6B3125D69, //yQA0
                                             0x404C9B913854F1E3, 0xA95CC8960AE25129, 0x87AE1BBCA460FCFC, 0xC1FF9E0E48F37ABE,
                                             0x6D48D512B84B1F5F, 0x8976739A3B78F8FB, 0x291374E9A768754B, 0x003A4D0AACD49E20}; //yQA1

const uint64_t RA_gen[4 * NWORDS64_FIELD] = {0xB5688C9F5D22E461, 0x93C58995B16E0FD0, 0xABF9E0E6BFB818D3, 0x2D2E3EFC7799EA9A,
                                             0x695C657844DA738F, 0xDBB53F432F0A34ED, 0x9BFB6CDB4065A720, 0x002CF86BF3C0E445, //xRA0
                                             0xD0E52AD26B607051, 0xEAFA244A08A22FAA, 0x9D9D1291363E69CD, 0x36216F81545C4D48,
                                             0x2B2714C5C0F5F847, 0xE3104A9BDD8BF4CF, 0x0C29598DC59344C1, 0x0071E6E0A381C8F1, //xRA1
                                             0xEF84A55A765E4052, 0x645214B3A78B3266, 0xFF83181E5DDD503B, 0xE7E37C2AB1B73B62,
                                             0x64AA7DC596A1C2C3, 0x34D88A5ECCC05DE5, 0xCE1B2DCC53ED9E09, 0x0000D0286C7E580D, //yRA0
                                             0x84C60F699D3C93B6, 0x75A1E7C49CA7986A, 0x5ECD6946CF049E3A, 0x74A04DCBF5B33486,
                                             0xBD01318C87E07879, 0xD49902BDD1C569A9, 0x873E779F36CF789D, 0x000F08F966794C94}; //yRA1

// Alice's generator values {WPA0 + WPA1*i, WQA0 + WQA1*i, WRA0 + WRA1*i} in GF(p503^2),precomputed by w=1/(x*y) and expressed in Montgomery representation
const uint64_t A_gen[6 * NWORDS64_FIELD] = {0x5D083011589AD893, 0xADFD8D2CB67D0637, 0x330C9AC34FFB6361, 0xF0D47489A2E805A2,
                                            0x27E2789259C6B8DC, 0x63866A2C121931B9, 0x8D4C65A7137DCF44, 0x003A183AE5967B3F, // WPA0
                                            0x7E3541B8C96D1519, 0xD3ADAEEC0D61A26C, 0xC0A2219CE7703DD9, 0xFF3E46658FCDBC52,
                                            0xD5B38DEAE6E196FF, 0x1AAC826364956D58, 0xEC9F4875B9A5F27A, 0x001B0B475AB99843, // WPA1
                                            0x4D83695107D03BAD, 0x221F3299005E2FCF, 0x78E6AE22F30DECF2, 0x6D982DB5111253E4,
                                            0x504C80A8AB4526A8, 0xEFD0C3AA210BB024, 0xCB77483501DC6FCF, 0x001052544A96BDF3, // WQA0
                                            0x0D74FE3402BCAE47, 0xDF5B8CDA832D8AED, 0xB86BCF06E4BD837E, 0x892A2933A0FA1F63,
                                            0x9F88FC67B6CCB461, 0x822926EA9DDA3AC8, 0xEAC8DDE5855425ED, 0x000618FE6DA37A80, // WQA1
                                            0x1D9D32D2DC877C17, 0x5517CD8F71D5B02B, 0x395AFB8F6B60C117, 0x3AE31AC85F9098C8,
                                            0x5F5341C198450848, 0xF8C609DBEA435C6A, 0xD832BC7EDC7BA5E4, 0x002AD98AA6968BF5, // WRA0
                                            0xC466CAB0F73C2E5B, 0x7B1817148FB2CF9C, 0x873E87C099E470A0, 0xBB17AC6D17A7BAC1,
                                            0xA146FDCD0F2E2A58, 0x88B311E9CEAB6201, 0x37604CF5C7951757, 0x0006804071C74BF9}; // WRA1

const uint64_t PB_gen[4 * NWORDS64_FIELD] = {0x0000000000000000, 0x0000000000000000, 0x0000000000000000, 0x0000000000000000,
                                             0x0000000000000000, 0x0000000000000000, 0x0000000000000000, 0x0000000000000000, //xPB0
                                             0x9EB8468AC9023B75, 0x1DEC933177A4B081, 0xB418891336368409, 0x29DD91BA0F4CC408,
                                             0x932FA1B890F925AC, 0x2A362D3C576050A5, 0x7C3985C61058C628, 0x00237B953F80E279, //xPB1
                                             0x0000000000000000, 0x0000000000000000, 0x0000000000000000, 0x0000000000000000,
                                             0x0000000000000000, 0x0000000000000000, 0x0000000000000000, 0x0000000000000000, //yPB0
                                             0x6E1E8991F12CFA0A, 0xAF7714AB5E7A5564, 0xA3123AB35D04DB0C, 0x3272A15924CD11FD,
                                             0x053E5E764A832348, 0x92C1B4C3A11C1D9D, 0xCAAFD3DE45B9EEC9, 0x002231A80A28E272}; //yPB1

const uint64_t QB_gen[4 * NWORDS64_FIELD] = {0x0000000000000000, 0x0000000000000000, 0x0000000000000000, 0x0000000000000000,
                                             0x0000000000000000, 0x0000000000000000, 0x0000000000000000, 0x0000000000000000, //xQB0
                                             0x8C01093F41096EA8, 0x60FE398B1E5B816D, 0x8E200F38D6FB4FFE, 0x4E19A83C4CFD56C3,
                                             0xE25AE3E5DC0C2EB6, 0xB6D092B04C36E42F, 0xA4161BEEF0FA2B8D, 0x003FA93365F3EE83, //xQB1
                                             0x0000000000000000, 0x0000000000000000, 0x0000000000000000, 0x0000000000000000,
                                             0x0000000000000000, 0x0000000000000000, 0x0000000000000000, 0x0000000000000000, //yQB0
                                             0x0F9E5B11AEDF94F2, 0xDD821FE2AD167B52, 0x2892F1CB020BF430, 0x8BFEC8AA94F697C2,
                                             0x089B689762C83093, 0x6F18E391D290755C, 0xB5118A7B2F97331C, 0x0037A0E5081D40B3}; //yQB1

const uint64_t RB_gen[4 * NWORDS64_FIELD] = {0x3A5A214D129FB5B3, 0x6D6D8A7D2010F8C5, 0x811E5EC93DD356DB, 0x5EE80CAA442DFE74,
                                             0x060FD298407D1952, 0x0883CE0F69EF4A3A, 0x236BF10036AE66B2, 0x000632319BC71B30, // xRB0
                                             0xA093D4D37AF83EE2, 0x1853339D42D0A684, 0x63AA6AAB85A74855, 0xBB24EA246366278A,
                                             0xFA0A2B3CA1E88366, 0xEE80CE9E2BF37482, 0xE752F45C204023C2, 0x001C1B8F2061479C, //xRB1
                                             0x13BCDF7924499943, 0xBCFED0AA024B3473, 0xE5514BBCC506DC66, 0xE992EC45FFF2EFE9,
                                             0x1303774C26906CCC, 0x7233E5CEA61B0FAB, 0x238E36F64A11EF08, 0x0024A263159BF01A, //yRA0
                                             0xE30AFC54DFB72129, 0x1F4AC90CCC9F2AF8, 0x8B691EA99383EDA7, 0x6582412B9A10A927,
                                             0xF2CA027FD118BB7E, 0x648DAD9670DFABE7, 0x1DC3257C029B7289, 0x00087AD1F776CAD9}; //yRA1

// Bob's generator values {WPB0, WQB0, WRB0 + WRB1*i} in GF(p503^2), precomputed by w=1/(x*y) and expressed in Montgomery representation
const uint64_t B_gen[6 * NWORDS64_FIELD] = {0xDF630FC5FB2468DB, 0xC30C5541C102040E, 0x3CDC9987B76511FC, 0xF54B5A09353D0CDD,
                                            0x3ADBA8E00703C42F, 0x8253F9303DDC95D0, 0x62D30778763ABFD7, 0x001CD00FB581CD55, // WPB0
                                            0x0000000000000000, 0x0000000000000000, 0x0000000000000000, 0x0000000000000000,
                                            0x0000000000000000, 0x0000000000000000, 0x0000000000000000, 0x0000000000000000, // WPB1
                                            0x2E3457A12B429261, 0x311F94E89627DCF8, 0x5B71C98FD1DB73F6, 0x3671DB7DCFC21541,
                                            0xB6D1484C9FE0CF4F, 0x19CD110717356E35, 0xF4F9FB00AC9919DF, 0x0035BC124D38A70B, // WQB0
                                            0x0000000000000000, 0x0000000000000000, 0x0000000000000000, 0x0000000000000000,
                                            0x0000000000000000, 0x0000000000000000, 0x0000000000000000, 0x0000000000000000, // WQB1
                                            0x2E08BB99413D2952, 0xD3021467CD088D72, 0x21017AF859752245, 0x26314ED8FFD9DE5C,
                                            0x4AF43C73344B6686, 0xCFA1F91149DF0993, 0xF327A95365587A89, 0x000DBF54E03D3906, // WRB0
                                            0x03E03FF342F5F304, 0x993D604D7B4B6E56, 0x80412F4D9280E71F, 0x0FFDC9EF990B3982,
                                            0xE584E64C51604931, 0x1374F42AC8B0BBD7, 0x07D5BC37DFA41A5F, 0x00396CCFD61FD34C}; // WRB1

// Montgomery constant Montgomery_R2 = (2^512)^2 mod p503
const uint64_t Montgomery_R2[NWORDS64_FIELD] = {0x5289A0CF641D011F, 0x9B88257189FED2B9, 0xA3B365D58DC8F17A, 0x5BC57AB6EFF168EC,
                                                0x9E51998BD84D4423, 0xBF8999CBAC3B5695, 0x46E9127BCE14CDB6, 0x003F6CFCE8B81771};
// Value one in Montgomery representation
const uint64_t Montgomery_one[NWORDS64_FIELD] = {0x00000000000003F9, 0x0000000000000000, 0x0000000000000000, 0xB400000000000000,
                                                 0x63CB1A6EA6DED2B4, 0x51689D8D667EB37D, 0x8ACD77C71AB24142, 0x0026FBAEC60F5953};

// Fixed parameters for isogeny tree computation
const unsigned int strat_Alice[MAX_Alice - 1] = {
    61, 32, 16, 8, 4, 2, 1, 1, 2, 1, 1, 4, 2, 1, 1, 2, 1, 1, 8, 4, 2, 1, 1, 2, 1, 1,
    4, 2, 1, 1, 2, 1, 1, 16, 8, 4, 2, 1, 1, 2, 1, 1, 4, 2, 1, 1, 2, 1, 1, 8, 4, 2, 1,
    1, 2, 1, 1, 4, 2, 1, 1, 2, 1, 1, 29, 16, 8, 4, 2, 1, 1, 2, 1, 1, 4, 2, 1, 1, 2, 1,
    1, 8, 4, 2, 1, 1, 2, 1, 1, 4, 2, 1, 1, 2, 1, 1, 13, 8, 4, 2, 1, 1, 2, 1, 1, 4, 2,
    1, 1, 2, 1, 1, 5, 4, 2, 1, 1, 2, 1, 1, 2, 1, 1, 1};

const unsigned int strat_Bob[MAX_Bob - 1] = {
    71, 38, 21, 13, 8, 4, 2, 1, 1, 2, 1, 1, 4, 2, 1, 1, 2, 1, 1, 5, 4, 2, 1, 1, 2, 1,
    1, 2, 1, 1, 1, 9, 5, 3, 2, 1, 1, 1, 1, 2, 1, 1, 1, 4, 2, 1, 1, 1, 2, 1, 1, 17, 9,
    5, 3, 2, 1, 1, 1, 1, 2, 1, 1, 1, 4, 2, 1, 1, 1, 2, 1, 1, 8, 4, 2, 1, 1, 1, 2, 1,
    1, 4, 2, 1, 1, 2, 1, 1, 33, 17, 9, 5, 3, 2, 1, 1, 1, 1, 2, 1, 1, 1, 4, 2, 1, 1, 1,
    2, 1, 1, 8, 4, 2, 1, 1, 1, 2, 1, 1, 4, 2, 1, 1, 2, 1, 1, 16, 8, 4, 2, 1, 1, 1, 2,
    1, 1, 4, 2, 1, 1, 2, 1, 1, 8, 4, 2, 1, 1, 2, 1, 1, 4, 2, 1, 1, 2, 1, 1};

// Setting up macro defines and including GF(p), GF(p^2), curve, isogeny and kex functions
#define fpcopy fpcopy503
#define fpzero fpzero503
#define fpadd fpadd503
#define fpsub fpsub503
#define fpneg fpneg503
#define fpdiv2 fpdiv2_503
#define fpcorrection fpcorrection503
#define fpmul_mont fpmul503_mont
#define fpsqr_mont fpsqr503_mont
#define fpinv_mont fpinv503_mont
#define fpinv_chain_mont fpinv503_chain_mont
#define fpinv_mont_bingcd fpinv503_mont_bingcd
#define fp2copy fp2copy503
#define fp2zero fp2zero503
#define fp2add fp2add503
#define fp2sub fp2sub503
#define fp2neg fp2neg503
#define fp2div2 fp2div2_503
#define fp2correction fp2correction503
#define fp2mul_mont fp2mul503_mont
#define fp2sqr_mont fp2sqr503_mont
#define fp2inv_mont fp2inv503_mont
#define fp2inv_mont_bingcd fp2inv503_mont_bingcd
#define fpequal_non_constant_time fpequal503_non_constant_time
#define mp_add_asm mp_add503_asm
#define mp_subaddx2_asm mp_subadd503x2_asm
#define mp_dblsubx2_asm mp_dblsub503x2_asm
#define crypto_kem_keypair crypto_kem_keypair_SIKEp503
#define crypto_kem_enc crypto_kem_enc_SIKEp503
#define crypto_kem_dec crypto_kem_dec_SIKEp503
#define random_mod_order_A random_mod_order_A_SIDHp503
#define random_mod_order_B random_mod_order_B_SIDHp503
#define EphemeralKeyGeneration_A EphemeralKeyGeneration_A_SIDHp503
#define EphemeralKeyGeneration_B EphemeralKeyGeneration_B_SIDHp503
#define EphemeralSecretAgreement_A EphemeralSecretAgreement_A_SIDHp503
#define EphemeralSecretAgreement_B EphemeralSecretAgreement_B_SIDHp503

#include "../fpx.c"
#include "../ec_isogeny.c"
#include "../sidh.c"
#include "../sike.c"